import { useState, useRef, useEffect } from 'react';
import { 
  MessageCircle, X, Send, User, Bot, ChevronRight,
  CreditCard, Phone, AlertTriangle, HelpCircle, Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { type Beneficiary } from '@/data/mockData';

interface Message {
  id: string;
  type: 'bot' | 'user';
  content: string;
  timestamp: Date;
  options?: { label: string; action: string }[];
}

interface ChatbotNanonProps {
  beneficiary?: Beneficiary | null;
}

export function ChatbotNanon({ beneficiary }: ChatbotNanonProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      // Initial greeting
      setTimeout(() => {
        const greeting = beneficiary 
          ? `Bonjour ${beneficiary.firstName}, je suis Nanon, votre assistante FIFA Pension. Comment puis-je vous aider aujourd'hui ?`
          : `Bonjour ! Je suis Nanon, votre assistante FIFA Pension. Comment puis-je vous aider aujourd'hui ?`;
        
        addBotMessage(greeting, [
          { label: '💰 Statut de mon paiement', action: 'payment_status' },
          { label: '📱 Changer mon numéro', action: 'change_number' },
          { label: '⚠️ Problème technique', action: 'technical_issue' },
          { label: '👤 Parler à un conseiller', action: 'human_agent' },
        ]);
      }, 500);
    }
  }, [isOpen, beneficiary]);

  const addBotMessage = (content: string, options?: { label: string; action: string }[]) => {
    setIsTyping(true);
    setTimeout(() => {
      setMessages(prev => [...prev, {
        id: `msg-${Date.now()}`,
        type: 'bot',
        content,
        timestamp: new Date(),
        options,
      }]);
      setIsTyping(false);
    }, 800);
  };

  const addUserMessage = (content: string) => {
    setMessages(prev => [...prev, {
      id: `msg-${Date.now()}`,
      type: 'user',
      content,
      timestamp: new Date(),
    }]);
  };

  const handleOptionClick = (action: string, label: string) => {
    addUserMessage(label);

    setTimeout(() => {
      switch (action) {
        case 'payment_status':
          if (beneficiary) {
            addBotMessage(
              `Votre prochain versement de ${beneficiary.monthlyAmount.toLocaleString()} FCFA est prévu pour le 15 du mois prochain.\n\nStatut actuel : ✅ Programmé\nCanal : ${beneficiary.paymentChannel.toUpperCase()}\nNuméro : ${beneficiary.channelNumber}`,
              [
                { label: '📜 Voir l\'historique', action: 'history' },
                { label: '🔙 Menu principal', action: 'main_menu' },
              ]
            );
          } else {
            addBotMessage(
              'Pour consulter le statut de votre paiement, veuillez vous connecter à votre espace personnel ou composer *123# sur votre téléphone.',
              [{ label: '🔙 Menu principal', action: 'main_menu' }]
            );
          }
          break;

        case 'change_number':
          addBotMessage(
            'Pour changer votre numéro de paiement :\n\n1️⃣ Composez *123#\n2️⃣ Choisissez "Modifier mon canal"\n3️⃣ Entrez le nouveau numéro\n4️⃣ Confirmez avec votre PIN\n\nOu rendez-vous dans votre profil sur l\'application.',
            [
              { label: '📱 Aller au profil', action: 'go_profile' },
              { label: '🔙 Menu principal', action: 'main_menu' },
            ]
          );
          break;

        case 'technical_issue':
          addBotMessage(
            'Je suis désolée d\'apprendre que vous rencontrez un problème. Pouvez-vous me décrire votre situation ?',
            [
              { label: '❌ Paiement non reçu', action: 'payment_not_received' },
              { label: '🔐 Problème de connexion', action: 'login_issue' },
              { label: '📞 Autre problème', action: 'other_issue' },
            ]
          );
          break;

        case 'payment_not_received':
          addBotMessage(
            'Si vous n\'avez pas reçu votre paiement :\n\n• Vérifiez que votre numéro de téléphone est correct dans votre profil\n• Les versements sont effectués entre le 10 et le 20 de chaque mois\n• Assurez-vous que votre preuve de vie est à jour\n\nSi le problème persiste, je vous mets en relation avec un conseiller.',
            [
              { label: '👤 Parler à un conseiller', action: 'human_agent' },
              { label: '🔙 Menu principal', action: 'main_menu' },
            ]
          );
          break;

        case 'human_agent':
          addBotMessage(
            '👤 Transfert vers un conseiller...\n\nNos conseillers sont disponibles :\n📅 Lundi - Vendredi\n🕐 8h00 - 17h00\n\n📞 Appelez le : +229 21 XX XX XX\n📧 Email : support@fifapension.bj\n\nTemps d\'attente estimé : ~5 minutes',
            [{ label: '🔙 Menu principal', action: 'main_menu' }]
          );
          break;

        case 'main_menu':
          addBotMessage(
            'Que puis-je faire d\'autre pour vous ?',
            [
              { label: '💰 Statut de mon paiement', action: 'payment_status' },
              { label: '📱 Changer mon numéro', action: 'change_number' },
              { label: '⚠️ Problème technique', action: 'technical_issue' },
              { label: '👤 Parler à un conseiller', action: 'human_agent' },
            ]
          );
          break;

        case 'history':
          addBotMessage(
            'Pour consulter votre historique complet de versements, rendez-vous dans la section "Historique" de votre espace personnel.\n\nVous y trouverez tous vos paiements des 12 derniers mois avec leurs détails.',
            [
              { label: '📜 Aller à l\'historique', action: 'go_history' },
              { label: '🔙 Menu principal', action: 'main_menu' },
            ]
          );
          break;

        default:
          addBotMessage(
            'Je ne suis pas sûre de comprendre. Pouvez-vous reformuler ou choisir une option ci-dessous ?',
            [
              { label: '💰 Statut de mon paiement', action: 'payment_status' },
              { label: '👤 Parler à un conseiller', action: 'human_agent' },
            ]
          );
      }
    }, 300);
  };

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;
    
    addUserMessage(inputValue);
    setInputValue('');

    // Simple keyword matching
    const lower = inputValue.toLowerCase();
    setTimeout(() => {
      if (lower.includes('paiement') || lower.includes('argent') || lower.includes('versement')) {
        handleOptionClick('payment_status', inputValue);
      } else if (lower.includes('numéro') || lower.includes('changer') || lower.includes('modifier')) {
        handleOptionClick('change_number', inputValue);
      } else if (lower.includes('problème') || lower.includes('erreur') || lower.includes('aide')) {
        handleOptionClick('technical_issue', inputValue);
      } else if (lower.includes('conseiller') || lower.includes('humain') || lower.includes('agent')) {
        handleOptionClick('human_agent', inputValue);
      } else {
        addBotMessage(
          'Je comprends votre demande. Pour mieux vous aider, pouvez-vous choisir une de ces options ?',
          [
            { label: '💰 Statut de mon paiement', action: 'payment_status' },
            { label: '📱 Changer mon numéro', action: 'change_number' },
            { label: '⚠️ Problème technique', action: 'technical_issue' },
            { label: '👤 Parler à un conseiller', action: 'human_agent' },
          ]
        );
      }
    }, 300);
  };

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(true)}
        className={`chatbot-bubble ${isOpen ? 'scale-0' : 'scale-100'}`}
        aria-label="Ouvrir le chatbot Nanon"
      >
        <MessageCircle className="h-6 w-6" />
        <span className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full animate-pulse" />
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="chatbot-window animate-scale-in flex flex-col">
          {/* Header */}
          <div className="bg-primary text-primary-foreground p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary-foreground/20 flex items-center justify-center">
                <Bot className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-semibold">Nanon</h3>
                <p className="text-xs text-primary-foreground/70">Assistante FIFA Pension</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(false)}
              className="text-primary-foreground hover:bg-primary-foreground/10"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'} animate-slide-up`}
              >
                <div
                  className={`max-w-[85%] ${
                    msg.type === 'user'
                      ? 'bg-primary text-primary-foreground rounded-2xl rounded-br-md'
                      : 'bg-secondary rounded-2xl rounded-bl-md'
                  } p-3`}
                >
                  <p className="text-sm whitespace-pre-line">{msg.content}</p>
                  
                  {/* Quick Reply Options */}
                  {msg.options && msg.options.length > 0 && (
                    <div className="mt-3 space-y-2">
                      {msg.options.map((opt, i) => (
                        <button
                          key={i}
                          onClick={() => handleOptionClick(opt.action, opt.label)}
                          className="w-full text-left px-3 py-2 bg-background/80 hover:bg-background rounded-lg text-sm font-medium transition-colors flex items-center justify-between group"
                        >
                          <span>{opt.label}</span>
                          <ChevronRight className="h-4 w-4 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex justify-start animate-fade-in">
                <div className="bg-secondary rounded-2xl rounded-bl-md p-3 flex items-center gap-1">
                  <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-border">
            <form 
              onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }}
              className="flex gap-2"
            >
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Écrivez votre message..."
                className="flex-1"
              />
              <Button type="submit" size="icon" disabled={!inputValue.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </form>
            <p className="text-xs text-muted-foreground text-center mt-2">
              Nanon est là pour vous aider 24h/24
            </p>
          </div>
        </div>
      )}
    </>
  );
}
