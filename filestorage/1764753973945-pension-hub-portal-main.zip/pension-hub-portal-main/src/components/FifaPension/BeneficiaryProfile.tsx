import { useState } from 'react';
import { 
  User, Phone, MapPin, Calendar, CreditCard, 
  Edit2, CheckCircle2, Shield, ArrowLeft, Save,
  AlertTriangle, Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { type Beneficiary } from '@/data/mockData';
import { toast } from '@/hooks/use-toast';

interface BeneficiaryProfileProps {
  beneficiary: Beneficiary;
  onBack: () => void;
  onUpdate: (updated: Beneficiary) => void;
}

export function BeneficiaryProfile({ beneficiary, onBack, onUpdate }: BeneficiaryProfileProps) {
  const [isEditingChannel, setIsEditingChannel] = useState(false);
  const [newChannel, setNewChannel] = useState(beneficiary.paymentChannel);
  const [newChannelNumber, setNewChannelNumber] = useState(beneficiary.channelNumber);
  const [isSaving, setIsSaving] = useState(false);

  const handleSaveChannel = async () => {
    setIsSaving(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    onUpdate({
      ...beneficiary,
      paymentChannel: newChannel,
      channelNumber: newChannelNumber,
    });
    
    setIsEditingChannel(false);
    setIsSaving(false);
    
    toast({
      title: "Canal mis à jour",
      description: "Votre nouveau canal de paiement a été enregistré.",
    });
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  };

  const getChannelIcon = (channel: string) => {
    switch (channel) {
      case 'mtn': return '📱 MTN MoMo';
      case 'moov': return '📱 Moov Money';
      case 'bank': return '🏦 Virement bancaire';
      default: return channel;
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground p-6 pb-20">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-4 mb-6">
            <Button 
              variant="ghost" 
              size="icon"
              className="text-primary-foreground hover:bg-primary-foreground/10"
              onClick={onBack}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-semibold">Mon profil</h1>
          </div>
          
          {/* Profile Header */}
          <div className="flex items-center gap-4">
            <img 
              src={beneficiary.photo} 
              alt="" 
              className="w-20 h-20 rounded-full border-4 border-primary-foreground/30"
            />
            <div>
              <h2 className="text-2xl font-bold">
                {beneficiary.firstName} {beneficiary.lastName}
              </h2>
              <p className="text-primary-foreground/80">ID: {beneficiary.id}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 -mt-12 space-y-4">
        {/* Payment Channel Card - Highlighted */}
        <Card className="p-6 border-2 border-primary/20 animate-slide-up">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-primary" />
              Canal de paiement
            </h3>
            {!isEditingChannel && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setIsEditingChannel(true)}
              >
                <Edit2 className="h-4 w-4 mr-2" />
                Modifier
              </Button>
            )}
          </div>

          {isEditingChannel ? (
            <div className="space-y-4 animate-fade-in">
              <div className="space-y-2">
                <Label>Type de canal</Label>
                <Select value={newChannel} onValueChange={(v) => setNewChannel(v as any)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mtn">📱 MTN MoMo</SelectItem>
                    <SelectItem value="moov">📱 Moov Money</SelectItem>
                    <SelectItem value="bank">🏦 Virement bancaire</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>{newChannel === 'bank' ? 'Numéro de compte' : 'Numéro de téléphone'}</Label>
                <Input
                  value={newChannelNumber}
                  onChange={(e) => setNewChannelNumber(e.target.value)}
                  placeholder={newChannel === 'bank' ? 'BJXXX...' : '+229 XX XX XX XX'}
                />
              </div>

              <div className="p-3 bg-warning/10 rounded-lg">
                <p className="text-sm text-warning flex items-start gap-2">
                  <AlertTriangle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  La modification prendra effet au prochain versement. Assurez-vous que le numéro est correct.
                </p>
              </div>

              <div className="flex gap-3">
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => {
                    setIsEditingChannel(false);
                    setNewChannel(beneficiary.paymentChannel);
                    setNewChannelNumber(beneficiary.channelNumber);
                  }}
                  disabled={isSaving}
                >
                  Annuler
                </Button>
                <Button 
                  className="flex-1"
                  onClick={handleSaveChannel}
                  disabled={isSaving}
                >
                  {isSaving ? (
                    <Clock className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="h-4 w-4 mr-2" />
                  )}
                  {isSaving ? 'Enregistrement...' : 'Enregistrer'}
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="p-4 bg-secondary/50 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Canal actuel</p>
                <p className="font-semibold">{getChannelIcon(beneficiary.paymentChannel)}</p>
              </div>
              <div className="p-4 bg-secondary/50 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">
                  {beneficiary.paymentChannel === 'bank' ? 'Numéro de compte' : 'Numéro'}
                </p>
                <p className="font-semibold font-mono">{beneficiary.channelNumber}</p>
              </div>
            </div>
          )}
        </Card>

        {/* Personal Info Card */}
        <Card className="p-6 animate-slide-up" style={{ animationDelay: '0.1s' }}>
          <h3 className="font-semibold flex items-center gap-2 mb-4">
            <User className="h-5 w-5 text-primary" />
            Informations personnelles
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-3 bg-secondary/50 rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Nom complet</p>
              <p className="font-medium">{beneficiary.firstName} {beneficiary.lastName}</p>
            </div>
            <div className="p-3 bg-secondary/50 rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Date de naissance</p>
              <p className="font-medium">{formatDate(beneficiary.dateOfBirth)}</p>
            </div>
            <div className="p-3 bg-secondary/50 rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Téléphone</p>
              <p className="font-medium">{beneficiary.phone}</p>
            </div>
            <div className="p-3 bg-secondary/50 rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Région</p>
              <p className="font-medium">{beneficiary.region}</p>
            </div>
            <div className="p-3 bg-secondary/50 rounded-lg md:col-span-2">
              <p className="text-sm text-muted-foreground mb-1">Adresse</p>
              <p className="font-medium">{beneficiary.address}</p>
            </div>
          </div>

          <p className="text-xs text-muted-foreground mt-4">
            Pour modifier ces informations, contactez votre agence locale ou appelez le support.
          </p>
        </Card>

        {/* Proof of Life Card */}
        <Card className="p-6 animate-slide-up" style={{ animationDelay: '0.15s' }}>
          <h3 className="font-semibold flex items-center gap-2 mb-4">
            <Shield className="h-5 w-5 text-primary" />
            Preuve de vie
          </h3>
          
          <div className="flex items-center justify-between p-4 bg-secondary/50 rounded-lg">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Statut</p>
              <Badge className={
                beneficiary.proofOfLifeStatus === 'valid' ? 'status-success' :
                beneficiary.proofOfLifeStatus === 'pending' ? 'status-warning' : 'status-error'
              }>
                {beneficiary.proofOfLifeStatus === 'valid' ? '✓ Validée' :
                 beneficiary.proofOfLifeStatus === 'pending' ? '⏳ En attente' : '⚠️ Expirée'}
              </Badge>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground mb-1">Dernière validation</p>
              <p className="font-medium">{formatDate(beneficiary.proofOfLifeDate)}</p>
            </div>
          </div>

          {beneficiary.proofOfLifeStatus !== 'valid' && (
            <Button className="w-full mt-4" variant="outline">
              <Shield className="h-4 w-4 mr-2" />
              Mettre à jour ma preuve de vie
            </Button>
          )}
        </Card>

        {/* Account Info */}
        <Card className="p-6 animate-slide-up" style={{ animationDelay: '0.2s' }}>
          <h3 className="font-semibold flex items-center gap-2 mb-4">
            <Calendar className="h-5 w-5 text-primary" />
            Informations du compte
          </h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="p-3 bg-secondary/50 rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Inscrit depuis</p>
              <p className="font-medium">{formatDate(beneficiary.registrationDate)}</p>
            </div>
            <div className="p-3 bg-secondary/50 rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Pension mensuelle</p>
              <p className="font-medium text-primary">{beneficiary.monthlyAmount.toLocaleString()} F</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
