import { useState } from 'react';
import { 
  Shield, User, Lock, Phone, Eye, EyeOff, 
  ArrowRight, AlertCircle, Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';

interface LoginPageProps {
  type: 'admin' | 'beneficiary';
  onLogin: (credentials: { username: string; password: string }) => void;
  onSwitchType: () => void;
}

export function LoginPage({ type, onLogin, onSwitchType }: LoginPageProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Demo credentials
    if (type === 'admin') {
      if (username === 'admin' && password === '1234') {
        onLogin({ username, password });
      } else {
        setError('Identifiants incorrects. Utilisez: admin / 1234');
      }
    } else {
      if (username.includes('229') && password.length === 4) {
        onLogin({ username, password });
      } else {
        setError('Numéro ou PIN incorrect. Utilisez un numéro béninois et un PIN à 4 chiffres.');
      }
    }
    
    setIsLoading(false);
  };

  return (
    <div className={`min-h-screen flex items-center justify-center p-4 ${
      type === 'admin' ? 'admin-theme bg-background' : 'bg-gradient-to-br from-primary/5 to-accent/5'
    }`}>
      <div className="w-full max-w-md">
        {/* Logo & Header */}
        <div className="text-center mb-8 animate-slide-up">
          <div className={`w-20 h-20 rounded-2xl mx-auto mb-4 flex items-center justify-center ${
            type === 'admin' 
              ? 'bg-primary text-primary-foreground' 
              : 'bg-gradient-to-br from-primary to-primary/80 text-primary-foreground'
          }`}>
            <Shield className="h-10 w-10" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-2">
            FIFA Pension
          </h1>
          <p className="text-muted-foreground">
            {type === 'admin' 
              ? 'Hub de Contrôle des Versements' 
              : 'La pension, l\'esprit tranquille'}
          </p>
        </div>

        {/* Login Card */}
        <Card className="p-6 shadow-lg animate-slide-up" style={{ animationDelay: '0.1s' }}>
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Username / Phone Field */}
            <div className="space-y-2">
              <Label htmlFor="username" className="text-sm font-medium">
                {type === 'admin' ? 'Identifiant' : 'Numéro de téléphone'}
              </Label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  {type === 'admin' ? <User className="h-4 w-4" /> : <Phone className="h-4 w-4" />}
                </div>
                <Input
                  id="username"
                  type={type === 'beneficiary' ? 'tel' : 'text'}
                  placeholder={type === 'admin' ? 'admin' : '+229 96 XX XX XX'}
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            {/* Password / PIN Field */}
            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-medium">
                {type === 'admin' ? 'Mot de passe' : 'Code PIN'}
              </Label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  <Lock className="h-4 w-4" />
                </div>
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder={type === 'admin' ? '••••••••' : '••••'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 pr-10"
                  maxLength={type === 'beneficiary' ? 4 : undefined}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {/* Error Message */}
            {error && (
              <div className="flex items-center gap-2 text-error text-sm bg-error/10 p-3 rounded-lg animate-fade-in">
                <AlertCircle className="h-4 w-4 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Submit Button */}
            <Button 
              type="submit" 
              className="w-full gap-2"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Connexion...
                </>
              ) : (
                <>
                  Se connecter
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </Button>

            {/* Forgot Password */}
            {type === 'beneficiary' && (
              <div className="text-center space-y-2">
                <button 
                  type="button"
                  className="text-sm text-primary hover:underline"
                >
                  PIN oublié ?
                </button>
                <p className="text-xs text-muted-foreground">
                  Première connexion ? Composez <span className="font-mono font-bold">*123#</span>
                </p>
              </div>
            )}
          </form>
        </Card>

        {/* Switch Login Type */}
        <div className="text-center mt-6 animate-slide-up" style={{ animationDelay: '0.2s' }}>
          <button
            onClick={onSwitchType}
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            {type === 'admin' 
              ? 'Accéder à l\'espace bénéficiaire →' 
              : '← Accès administrateur'}
          </button>
        </div>

        {/* Demo Credentials */}
        <div className="mt-6 p-4 bg-muted/50 rounded-lg text-sm text-center animate-slide-up" style={{ animationDelay: '0.3s' }}>
          <p className="text-muted-foreground mb-1">Identifiants de démonstration :</p>
          {type === 'admin' ? (
            <p className="font-mono">admin / 1234</p>
          ) : (
            <p className="font-mono">+229 96XXXXXX / 1234</p>
          )}
        </div>
      </div>
    </div>
  );
}
