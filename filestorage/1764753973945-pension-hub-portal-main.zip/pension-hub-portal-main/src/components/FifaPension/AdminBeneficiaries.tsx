import { useState } from 'react';
import { 
  Search, Filter, Download, Eye, Edit2, MoreVertical,
  CheckCircle2, AlertTriangle, Clock, ChevronLeft, ChevronRight,
  Phone, MapPin, Calendar, Shield, CreditCard, RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { beneficiaries, transactions, type Beneficiary } from '@/data/mockData';

interface AdminBeneficiariesProps {
  onSelectBeneficiary: (ben: Beneficiary) => void;
}

export function AdminBeneficiaries({ onSelectBeneficiary }: AdminBeneficiariesProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [polFilter, setPolFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedBen, setSelectedBen] = useState<Beneficiary | null>(null);
  const itemsPerPage = 10;

  const filtered = beneficiaries.filter(b => {
    const matchesSearch = 
      b.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.phone.includes(searchTerm) ||
      b.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || b.status === statusFilter;
    const matchesPol = polFilter === 'all' || b.proofOfLifeStatus === polFilter;
    return matchesSearch && matchesStatus && matchesPol;
  });

  const totalPages = Math.ceil(filtered.length / itemsPerPage);
  const paginated = filtered.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const getLastTransaction = (benId: string) => {
    const txns = transactions.filter(t => t.beneficiaryId === benId);
    return txns[0];
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="status-success">Actif</Badge>;
      case 'suspended':
        return <Badge className="status-warning">Suspendu</Badge>;
      case 'deceased':
        return <Badge className="status-error">Décédé</Badge>;
      default:
        return null;
    }
  };

  const getPolBadge = (status: string) => {
    switch (status) {
      case 'valid':
        return <Badge variant="outline" className="status-success">✓ Valide</Badge>;
      case 'pending':
        return <Badge variant="outline" className="status-warning">⏳ En attente</Badge>;
      case 'expired':
        return <Badge variant="outline" className="status-error">⚠️ Expirée</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Gestion des bénéficiaires</h1>
          <p className="text-muted-foreground">{filtered.length} bénéficiaires trouvés</p>
        </div>
        <Button variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          Exporter
        </Button>
      </div>

      {/* Filters */}
      <Card className="p-4">
        <div className="flex flex-wrap gap-4">
          <div className="flex-1 min-w-[200px]">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Rechercher par nom, téléphone, ID..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1);
                }}
              />
            </div>
          </div>
          <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setCurrentPage(1); }}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Statut" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous statuts</SelectItem>
              <SelectItem value="active">Actif</SelectItem>
              <SelectItem value="suspended">Suspendu</SelectItem>
              <SelectItem value="deceased">Décédé</SelectItem>
            </SelectContent>
          </Select>
          <Select value={polFilter} onValueChange={(v) => { setPolFilter(v); setCurrentPage(1); }}>
            <SelectTrigger className="w-[170px]">
              <SelectValue placeholder="Preuve de vie" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Toutes PDV</SelectItem>
              <SelectItem value="valid">Valide</SelectItem>
              <SelectItem value="pending">En attente</SelectItem>
              <SelectItem value="expired">Expirée</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Table */}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-secondary/50">
                <th className="text-left p-4 font-medium text-sm">Bénéficiaire</th>
                <th className="text-left p-4 font-medium text-sm">Téléphone</th>
                <th className="text-left p-4 font-medium text-sm">Canal</th>
                <th className="text-left p-4 font-medium text-sm">Preuve de vie</th>
                <th className="text-left p-4 font-medium text-sm">Dernier versement</th>
                <th className="text-left p-4 font-medium text-sm">Statut</th>
                <th className="text-center p-4 font-medium text-sm">Actions</th>
              </tr>
            </thead>
            <tbody>
              {paginated.map((ben, i) => {
                const lastTxn = getLastTransaction(ben.id);
                return (
                  <tr 
                    key={ben.id}
                    className="border-b border-border hover:bg-secondary/30 transition-colors animate-fade-in"
                    style={{ animationDelay: `${i * 0.03}s` }}
                  >
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <img src={ben.photo} alt="" className="w-10 h-10 rounded-full bg-muted" />
                        <div>
                          <p className="font-medium">{ben.firstName} {ben.lastName}</p>
                          <p className="text-xs text-muted-foreground">{ben.id}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="font-mono text-sm">{ben.phone}</span>
                    </td>
                    <td className="p-4">
                      <span className="text-sm capitalize">{ben.paymentChannel}</span>
                    </td>
                    <td className="p-4">
                      {getPolBadge(ben.proofOfLifeStatus)}
                    </td>
                    <td className="p-4">
                      {lastTxn && (
                        <div className="flex items-center gap-2">
                          {lastTxn.status === 'success' ? (
                            <CheckCircle2 className="h-4 w-4 text-success" />
                          ) : lastTxn.status === 'pending' ? (
                            <Clock className="h-4 w-4 text-warning" />
                          ) : (
                            <AlertTriangle className="h-4 w-4 text-error" />
                          )}
                          <span className="text-sm">
                            {new Date(lastTxn.date).toLocaleDateString('fr-FR', { 
                              day: '2-digit', 
                              month: 'short' 
                            })}
                          </span>
                        </div>
                      )}
                    </td>
                    <td className="p-4">
                      {getStatusBadge(ben.status)}
                    </td>
                    <td className="p-4">
                      <div className="flex items-center justify-center gap-1">
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => setSelectedBen(ben)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => setSelectedBen(ben)}>
                              <Eye className="h-4 w-4 mr-2" />
                              Voir la fiche
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit2 className="h-4 w-4 mr-2" />
                              Modifier
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <RefreshCw className="h-4 w-4 mr-2" />
                              Forcer PDV
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between p-4 border-t border-border">
          <p className="text-sm text-muted-foreground">
            Page {currentPage} sur {totalPages}
          </p>
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(p => p - 1)}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(p => p + 1)}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </Card>

      {/* Beneficiary Detail Modal */}
      {selectedBen && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto animate-scale-in">
            <div className="p-6">
              {/* Header */}
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center gap-4">
                  <img src={selectedBen.photo} alt="" className="w-16 h-16 rounded-full bg-muted" />
                  <div>
                    <h2 className="text-xl font-bold">{selectedBen.firstName} {selectedBen.lastName}</h2>
                    <p className="text-muted-foreground">{selectedBen.id}</p>
                    {getStatusBadge(selectedBen.status)}
                  </div>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setSelectedBen(null)}>
                  ✕
                </Button>
              </div>

              {/* Info Grid */}
              <div className="grid md:grid-cols-2 gap-6">
                {/* Personal Info */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">
                    Informations personnelles
                  </h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 p-3 bg-secondary/50 rounded-lg">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-xs text-muted-foreground">Téléphone</p>
                        <p className="font-mono">{selectedBen.phone}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-secondary/50 rounded-lg">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-xs text-muted-foreground">Adresse</p>
                        <p>{selectedBen.address}, {selectedBen.region}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-secondary/50 rounded-lg">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-xs text-muted-foreground">Date de naissance</p>
                        <p>{new Date(selectedBen.dateOfBirth).toLocaleDateString('fr-FR')}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Payment Info */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">
                    Paiement
                  </h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 p-3 bg-primary/5 border border-primary/20 rounded-lg">
                      <CreditCard className="h-4 w-4 text-primary" />
                      <div>
                        <p className="text-xs text-muted-foreground">Canal de paiement</p>
                        <p className="font-semibold uppercase">{selectedBen.paymentChannel}</p>
                        <p className="text-sm font-mono">{selectedBen.channelNumber}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-secondary/50 rounded-lg">
                      <Shield className="h-4 w-4 text-muted-foreground" />
                      <div className="flex-1">
                        <p className="text-xs text-muted-foreground">Preuve de vie</p>
                        <div className="flex items-center justify-between">
                          {getPolBadge(selectedBen.proofOfLifeStatus)}
                          <span className="text-xs text-muted-foreground">
                            {new Date(selectedBen.proofOfLifeDate).toLocaleDateString('fr-FR')}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 bg-secondary/50 rounded-lg">
                      <p className="text-xs text-muted-foreground mb-1">Pension mensuelle</p>
                      <p className="text-2xl font-bold text-primary">
                        {selectedBen.monthlyAmount.toLocaleString()} <span className="text-sm">FCFA</span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Recent Transactions */}
              <div className="mt-6">
                <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide mb-3">
                  Derniers versements
                </h3>
                <div className="space-y-2">
                  {transactions
                    .filter(t => t.beneficiaryId === selectedBen.id)
                    .slice(0, 5)
                    .map(txn => (
                      <div key={txn.id} className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                        <div className="flex items-center gap-3">
                          {txn.status === 'success' ? (
                            <CheckCircle2 className="h-4 w-4 text-success" />
                          ) : txn.status === 'pending' ? (
                            <Clock className="h-4 w-4 text-warning" />
                          ) : (
                            <AlertTriangle className="h-4 w-4 text-error" />
                          )}
                          <span className="text-sm">
                            {new Date(txn.date).toLocaleDateString('fr-FR', { 
                              day: 'numeric',
                              month: 'long',
                              year: 'numeric'
                            })}
                          </span>
                        </div>
                        <span className={`font-semibold ${
                          txn.status === 'success' ? 'text-success' :
                          txn.status === 'failed' ? 'text-error' : 'text-warning'
                        }`}>
                          {txn.amount.toLocaleString()} F
                        </span>
                      </div>
                    ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3 mt-6 pt-6 border-t border-border">
                <Button variant="outline" className="flex-1" onClick={() => setSelectedBen(null)}>
                  Fermer
                </Button>
                <Button variant="outline" className="flex-1">
                  <Edit2 className="h-4 w-4 mr-2" />
                  Modifier
                </Button>
                {selectedBen.proofOfLifeStatus !== 'valid' && (
                  <Button className="flex-1">
                    <Shield className="h-4 w-4 mr-2" />
                    Forcer PDV
                  </Button>
                )}
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
