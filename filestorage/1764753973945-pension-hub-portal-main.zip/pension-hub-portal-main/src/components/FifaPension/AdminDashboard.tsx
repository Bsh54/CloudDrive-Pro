import { useState, useEffect } from 'react';
import { 
  BarChart3, Users, AlertTriangle, CheckCircle2, Clock, 
  TrendingUp, Activity, RefreshCw, ChevronRight, Search,
  AlertCircle, Zap, Eye, Edit2, MoreVertical
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  beneficiaries, paymentErrors, fspStatuses, calculateKPIs, 
  mojaErrorCodes, type Beneficiary, type PaymentError 
} from '@/data/mockData';

interface AdminDashboardProps {
  onNavigate: (view: string) => void;
  onSelectBeneficiary: (ben: Beneficiary) => void;
}

export function AdminDashboard({ onNavigate, onSelectBeneficiary }: AdminDashboardProps) {
  const [kpis, setKpis] = useState(calculateKPIs());
  const [errors, setErrors] = useState(paymentErrors.filter(e => e.status === 'pending'));
  const [selectedError, setSelectedError] = useState<PaymentError | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setKpis(prev => ({
        ...prev,
        successRate: Math.min(100, prev.successRate + (Math.random() - 0.5) * 0.2),
        liquidityAvailable: prev.liquidityAvailable - Math.floor(Math.random() * 50000),
      }));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setKpis(calculateKPIs());
      setIsRefreshing(false);
    }, 1000);
  };

  const handleResolveError = (errorId: string) => {
    setErrors(prev => prev.filter(e => e.id !== errorId));
    setSelectedError(null);
  };

  const getTimeSince = (timestamp: string) => {
    const diff = Date.now() - new Date(timestamp).getTime();
    const minutes = Math.floor(diff / 60000);
    if (minutes < 60) return `Il y a ${minutes}min`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `Il y a ${hours}h`;
    return `Il y a ${Math.floor(hours / 24)}j`;
  };

  const filteredBeneficiaries = beneficiaries.filter(b => 
    b.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    b.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    b.phone.includes(searchTerm)
  ).slice(0, 10);

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Hub de Contrôle des Versements</h1>
          <p className="text-muted-foreground">Tableau de bord opérationnel</p>
        </div>
        <Button 
          onClick={handleRefresh} 
          variant="outline" 
          className="gap-2"
          disabled={isRefreshing}
        >
          <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          Actualiser
        </Button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Success Rate */}
        <Card className="kpi-card">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 rounded-lg bg-success/10">
              <CheckCircle2 className="h-5 w-5 text-success" />
            </div>
            <Badge variant="outline" className="status-success">En temps réel</Badge>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Taux de réussite</p>
            <div className="flex items-end gap-2">
              <span className="text-3xl font-bold text-success">{kpis.successRate.toFixed(1)}%</span>
              <TrendingUp className="h-4 w-4 text-success mb-1" />
            </div>
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <div 
                className="h-full bg-success rounded-full transition-all duration-500"
                style={{ width: `${kpis.successRate}%` }}
              />
            </div>
          </div>
        </Card>

        {/* Liquidity */}
        <Card className="kpi-card">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 rounded-lg bg-accent/20">
              <BarChart3 className="h-5 w-5 text-accent" />
            </div>
            <span className="text-xs text-muted-foreground">Ce mois</span>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Liquidité disponible</p>
            <span className="text-2xl font-bold text-foreground">
              {(kpis.liquidityAvailable / 1000000).toFixed(1)}M
            </span>
            <p className="text-xs text-muted-foreground">FCFA sur {kpis.monthlyBudget / 1000000}M budget</p>
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <div 
                className="h-full bg-accent rounded-full transition-all duration-500"
                style={{ width: `${(kpis.liquidityAvailable / kpis.monthlyBudget) * 100}%` }}
              />
            </div>
          </div>
        </Card>

        {/* Pending Errors */}
        <Card className={`kpi-card ${errors.length > 0 ? 'border-error/50' : ''}`}>
          <div className="flex items-center justify-between mb-4">
            <div className={`p-2 rounded-lg ${errors.length > 0 ? 'bg-error/10' : 'bg-muted'}`}>
              <AlertTriangle className={`h-5 w-5 ${errors.length > 0 ? 'text-error animate-pulse' : 'text-muted-foreground'}`} />
            </div>
            {errors.length > 0 && (
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-error opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-error" />
              </span>
            )}
          </div>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Erreurs en attente</p>
            <span className={`text-3xl font-bold ${errors.length > 0 ? 'text-error' : 'text-foreground'}`}>
              {errors.length}
            </span>
            <Button 
              variant="ghost" 
              size="sm" 
              className="w-full justify-between text-error hover:text-error hover:bg-error/10"
              onClick={() => onNavigate('errors')}
            >
              Voir les erreurs <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </Card>

        {/* Total Paid */}
        <Card className="kpi-card">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 rounded-lg bg-primary/10">
              <Zap className="h-5 w-5 text-primary" />
            </div>
            <span className="text-xs text-muted-foreground">Ce mois</span>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Montant total versé</p>
            <span className="text-2xl font-bold text-foreground">
              {(kpis.totalAmount / 1000000).toFixed(1)}M
            </span>
            <p className="text-xs text-muted-foreground">FCFA • {kpis.totalBeneficiaries} bénéficiaires</p>
          </div>
        </Card>
      </div>

      {/* FSP Health & Recent Errors */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* FSP Health */}
        <Card className="kpi-card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Météo FSP
            </h3>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </div>
          <div className="space-y-3">
            {fspStatuses.map(fsp => (
              <div key={fsp.code} className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className={
                    fsp.status === 'healthy' ? 'fsp-healthy' : 
                    fsp.status === 'warning' ? 'fsp-warning' : 'fsp-critical'
                  } />
                  <div>
                    <p className="font-medium text-sm">{fsp.name}</p>
                    <p className="text-xs text-muted-foreground">{fsp.latency}ms latence</p>
                  </div>
                </div>
                <Badge variant="outline" className={
                  fsp.status === 'healthy' ? 'status-success' : 
                  fsp.status === 'warning' ? 'status-warning' : 'status-error'
                }>
                  {fsp.successRate}%
                </Badge>
              </div>
            ))}
          </div>
        </Card>

        {/* Recent Errors */}
        <Card className="kpi-card lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-error" />
              Erreurs récentes
            </h3>
            <Button variant="ghost" size="sm" onClick={() => onNavigate('errors')}>
              Voir tout <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          <div className="space-y-2 max-h-[280px] overflow-y-auto scrollbar-thin">
            {errors.slice(0, 5).map((error, i) => {
              const ben = beneficiaries.find(b => b.id === error.beneficiaryId);
              return (
                <div 
                  key={error.id}
                  className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg hover:bg-secondary transition-colors cursor-pointer"
                  style={{ animationDelay: `${i * 0.1}s` }}
                  onClick={() => setSelectedError(error)}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-error/10 flex items-center justify-center">
                      <AlertTriangle className="h-5 w-5 text-error" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{ben?.firstName} {ben?.lastName}</p>
                      <p className="text-xs text-muted-foreground">
                        [{error.mojaCode}] {error.humanMessage}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{error.amount.toLocaleString()} F</p>
                    <p className="text-xs text-muted-foreground">{getTimeSince(error.timestamp)}</p>
                  </div>
                </div>
              );
            })}
            {errors.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <CheckCircle2 className="h-12 w-12 mx-auto mb-2 text-success" />
                <p>Aucune erreur en attente</p>
              </div>
            )}
          </div>
        </Card>
      </div>

      {/* Quick Beneficiary Search */}
      <Card className="kpi-card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold flex items-center gap-2">
            <Users className="h-4 w-4" />
            Recherche rapide
          </h3>
          <Button variant="ghost" size="sm" onClick={() => onNavigate('beneficiaries')}>
            Gestion complète <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Rechercher par nom ou téléphone..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        {searchTerm && (
          <div className="space-y-2 animate-fade-in">
            {filteredBeneficiaries.map(ben => (
              <div 
                key={ben.id}
                className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg hover:bg-secondary transition-colors cursor-pointer"
                onClick={() => onSelectBeneficiary(ben)}
              >
                <div className="flex items-center gap-3">
                  <img src={ben.photo} alt="" className="w-10 h-10 rounded-full bg-muted" />
                  <div>
                    <p className="font-medium text-sm">{ben.firstName} {ben.lastName}</p>
                    <p className="text-xs text-muted-foreground">{ben.phone}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className={
                    ben.proofOfLifeStatus === 'valid' ? 'status-success' :
                    ben.proofOfLifeStatus === 'pending' ? 'status-warning' : 'status-error'
                  }>
                    {ben.proofOfLifeStatus === 'valid' ? 'Actif' : 
                     ben.proofOfLifeStatus === 'pending' ? 'En attente' : 'Expiré'}
                  </Badge>
                  <Button variant="ghost" size="icon">
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Error Resolution Modal */}
      {selectedError && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <Card className="w-full max-w-lg p-6 animate-scale-in">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 rounded-full bg-error/10">
                <AlertTriangle className="h-6 w-6 text-error" />
              </div>
              <div>
                <h2 className="text-xl font-semibold">Échec de versement</h2>
                <p className="text-sm text-muted-foreground">Intervention requise</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="p-4 bg-secondary rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Code Mojaloop</p>
                <code className="text-sm font-mono text-error">
                  [{selectedError.mojaCode} - {mojaErrorCodes[selectedError.mojaCode]?.code}]
                </code>
              </div>

              <div className="p-4 bg-secondary rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Explication</p>
                <p className="text-sm font-medium">{selectedError.humanMessage}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Montant</p>
                  <p className="font-semibold">{selectedError.amount.toLocaleString()} FCFA</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">FSP</p>
                  <p className="font-semibold">{selectedError.fsp}</p>
                </div>
              </div>

              <div>
                <p className="text-xs text-muted-foreground mb-2">Tentatives: {selectedError.attempts}</p>
                <div className="flex gap-1">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <div 
                      key={i}
                      className={`h-1.5 flex-1 rounded-full ${i < selectedError.attempts ? 'bg-error' : 'bg-muted'}`}
                    />
                  ))}
                </div>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => setSelectedError(null)}
              >
                Annuler
              </Button>
              <Button 
                className="flex-1 bg-success hover:bg-success/90"
                onClick={() => handleResolveError(selectedError.id)}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Redéclencher le paiement
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
