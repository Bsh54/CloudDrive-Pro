import { useState } from 'react';
import { 
  HelpCircle, ChevronDown, ChevronRight, Phone, Mail, 
  Clock, MessageCircle, ArrowLeft, Search, FileText
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface BeneficiaryHelpProps {
  onBack: () => void;
}

export function BeneficiaryHelp({ onBack }: BeneficiaryHelpProps) {
  const [searchTerm, setSearchTerm] = useState('');

  const faqCategories = [
    {
      title: "Versements",
      icon: "💰",
      questions: [
        {
          q: "Quand vais-je recevoir ma pension ?",
          a: "Les versements sont effectués entre le 10 et le 20 de chaque mois. La date exacte dépend de votre canal de paiement et des jours ouvrés."
        },
        {
          q: "Pourquoi mon paiement a-t-il échoué ?",
          a: "Un échec de paiement peut survenir si : votre numéro de téléphone est incorrect, votre compte mobile money est inactif, ou si votre preuve de vie a expiré. Vérifiez ces éléments dans votre profil ou composez *123#."
        },
        {
          q: "Comment vérifier le statut de mon paiement ?",
          a: "Vous pouvez vérifier le statut de votre paiement depuis votre tableau de bord, via le USSD *123#, ou en contactant notre chatbot Nanon."
        },
      ]
    },
    {
      title: "Canal de paiement",
      icon: "📱",
      questions: [
        {
          q: "Comment changer mon numéro de paiement ?",
          a: "Rendez-vous dans votre profil, section 'Canal de paiement', puis cliquez sur 'Modifier'. Vous pouvez également utiliser le USSD *123# ou contacter le support."
        },
        {
          q: "Quels sont les canaux de paiement disponibles ?",
          a: "Nous proposons : MTN Mobile Money, Moov Money, et le virement bancaire pour les comptes BCEAO. Le mobile money est recommandé pour plus de rapidité."
        },
        {
          q: "Puis-je avoir plusieurs canaux de paiement ?",
          a: "Non, un seul canal de paiement est actif à la fois. Vous pouvez le modifier à tout moment, le changement prendra effet au prochain versement."
        },
      ]
    },
    {
      title: "Preuve de vie",
      icon: "🛡️",
      questions: [
        {
          q: "Qu'est-ce que la preuve de vie ?",
          a: "La preuve de vie est une vérification annuelle obligatoire qui confirme que vous êtes toujours en vie et éligible aux versements de pension."
        },
        {
          q: "Comment faire ma preuve de vie ?",
          a: "Rendez-vous dans votre agence locale avec une pièce d'identité valide, ou utilisez l'option de preuve de vie digitale via notre application si disponible dans votre région."
        },
        {
          q: "Que se passe-t-il si ma preuve de vie expire ?",
          a: "Si votre preuve de vie expire, vos versements seront suspendus jusqu'à ce que vous la renouveliez. Vous recevrez des rappels 30 jours avant l'expiration."
        },
      ]
    },
    {
      title: "Compte et sécurité",
      icon: "🔐",
      questions: [
        {
          q: "J'ai oublié mon code PIN",
          a: "Composez *123# et suivez les instructions pour réinitialiser votre PIN, ou rendez-vous dans votre agence locale avec votre pièce d'identité."
        },
        {
          q: "Comment protéger mon compte ?",
          a: "Ne partagez jamais votre code PIN. FIFA Pension ne vous demandera jamais votre PIN par téléphone ou SMS. En cas de doute, contactez notre support."
        },
        {
          q: "Comment mettre à jour mes informations personnelles ?",
          a: "Pour modifier vos informations personnelles (nom, adresse, etc.), contactez votre agence locale ou appelez notre service client."
        },
      ]
    },
  ];

  const filteredFaqs = searchTerm
    ? faqCategories.map(cat => ({
        ...cat,
        questions: cat.questions.filter(
          q => q.q.toLowerCase().includes(searchTerm.toLowerCase()) ||
               q.a.toLowerCase().includes(searchTerm.toLowerCase())
        )
      })).filter(cat => cat.questions.length > 0)
    : faqCategories;

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-primary text-primary-foreground p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="icon"
              className="text-primary-foreground hover:bg-primary-foreground/10"
              onClick={onBack}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-semibold">Centre d'aide</h1>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        {/* Search */}
        <div className="relative animate-slide-up">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Rechercher dans l'aide..."
            className="pl-12 h-12 text-base"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        {/* Quick Contacts */}
        <Card className="p-4 animate-slide-up" style={{ animationDelay: '0.1s' }}>
          <h2 className="font-semibold mb-4 flex items-center gap-2">
            <Phone className="h-5 w-5 text-primary" />
            Contactez-nous
          </h2>
          <div className="grid sm:grid-cols-3 gap-4">
            <div className="p-4 bg-secondary/50 rounded-lg text-center">
              <Phone className="h-6 w-6 mx-auto mb-2 text-primary" />
              <p className="font-semibold">Téléphone</p>
              <p className="text-sm text-muted-foreground">+229 21 XX XX XX</p>
            </div>
            <div className="p-4 bg-secondary/50 rounded-lg text-center">
              <Mail className="h-6 w-6 mx-auto mb-2 text-primary" />
              <p className="font-semibold">Email</p>
              <p className="text-sm text-muted-foreground">support@fifapension.bj</p>
            </div>
            <div className="p-4 bg-secondary/50 rounded-lg text-center">
              <Clock className="h-6 w-6 mx-auto mb-2 text-primary" />
              <p className="font-semibold">Horaires</p>
              <p className="text-sm text-muted-foreground">Lun-Ven 8h-17h</p>
            </div>
          </div>
        </Card>

        {/* USSD Reminder */}
        <Card className="p-4 bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20 animate-slide-up" style={{ animationDelay: '0.15s' }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                <Phone className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-semibold">Service USSD</p>
                <p className="text-sm text-muted-foreground">Disponible 24h/24 sans internet</p>
              </div>
            </div>
            <span className="text-2xl font-mono font-bold text-primary">*123#</span>
          </div>
        </Card>

        {/* FAQ */}
        <div className="space-y-4 animate-slide-up" style={{ animationDelay: '0.2s' }}>
          <h2 className="font-semibold text-lg flex items-center gap-2">
            <HelpCircle className="h-5 w-5 text-primary" />
            Questions fréquentes
          </h2>

          {filteredFaqs.map((category, i) => (
            <Card key={category.title} className="overflow-hidden">
              <div className="p-4 bg-secondary/30 border-b border-border">
                <h3 className="font-semibold flex items-center gap-2">
                  <span>{category.icon}</span>
                  {category.title}
                </h3>
              </div>
              <Accordion type="single" collapsible className="px-4">
                {category.questions.map((faq, j) => (
                  <AccordionItem key={j} value={`${i}-${j}`}>
                    <AccordionTrigger className="text-left">
                      {faq.q}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground">
                      {faq.a}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </Card>
          ))}

          {filteredFaqs.length === 0 && (
            <Card className="p-8 text-center">
              <HelpCircle className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground">Aucun résultat pour "{searchTerm}"</p>
              <Button 
                variant="link" 
                className="mt-2"
                onClick={() => setSearchTerm('')}
              >
                Effacer la recherche
              </Button>
            </Card>
          )}
        </div>

        {/* Chatbot CTA */}
        <Card className="p-6 text-center animate-slide-up" style={{ animationDelay: '0.25s' }}>
          <MessageCircle className="h-12 w-12 mx-auto text-primary mb-4" />
          <h3 className="font-semibold text-lg mb-2">Besoin d'aide immédiate ?</h3>
          <p className="text-muted-foreground mb-4">
            Notre assistante Nanon est disponible 24h/24 pour répondre à vos questions.
          </p>
          <p className="text-sm text-muted-foreground">
            Cliquez sur l'icône de chat en bas à droite pour commencer.
          </p>
        </Card>

        {/* Documents */}
        <Card className="p-4 animate-slide-up" style={{ animationDelay: '0.3s' }}>
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            Documents utiles
          </h3>
          <div className="space-y-2">
            {[
              'Guide d\'utilisation FIFA Pension',
              'Formulaire de changement de canal',
              'Procédure de preuve de vie',
              'Conditions générales'
            ].map((doc, i) => (
              <button
                key={i}
                className="w-full flex items-center justify-between p-3 bg-secondary/50 rounded-lg hover:bg-secondary transition-colors"
              >
                <span className="text-sm">{doc}</span>
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </button>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
