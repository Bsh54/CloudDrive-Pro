import { useState } from 'react';
import { 
  Calendar, CheckCircle2, AlertTriangle, Clock, 
  Download, Filter, ChevronDown, FileText, ArrowLeft
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { type Beneficiary, type Transaction, transactions } from '@/data/mockData';

interface BeneficiaryHistoryProps {
  beneficiary: Beneficiary;
  onBack: () => void;
}

export function BeneficiaryHistory({ beneficiary, onBack }: BeneficiaryHistoryProps) {
  const [yearFilter, setYearFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const benTransactions = transactions.filter(t => t.beneficiaryId === beneficiary.id);
  
  const filteredTransactions = benTransactions.filter(t => {
    const txnYear = new Date(t.date).getFullYear().toString();
    const matchesYear = yearFilter === 'all' || txnYear === yearFilter;
    const matchesStatus = statusFilter === 'all' || t.status === statusFilter;
    return matchesYear && matchesStatus;
  });

  const years = [...new Set(benTransactions.map(t => 
    new Date(t.date).getFullYear()
  ))].sort((a, b) => b - a);

  const totalSuccess = filteredTransactions
    .filter(t => t.status === 'success')
    .reduce((sum, t) => sum + t.amount, 0);

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle2 className="h-5 w-5 text-success" />;
      case 'pending':
        return <Clock className="h-5 w-5 text-warning" />;
      case 'failed':
        return <AlertTriangle className="h-5 w-5 text-error" />;
      default:
        return null;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'success': return 'Reçu';
      case 'pending': return 'En attente';
      case 'failed': return 'Échec';
      default: return status;
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-primary text-primary-foreground p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="icon"
              className="text-primary-foreground hover:bg-primary-foreground/10"
              onClick={onBack}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-semibold">Historique des versements</h1>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-6 space-y-4">
        {/* Summary Card */}
        <Card className="p-4 bg-gradient-to-r from-primary/5 to-accent/5 animate-slide-up">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Total reçu</p>
              <p className="text-2xl font-bold text-primary">
                {totalSuccess.toLocaleString()} <span className="text-base">FCFA</span>
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground mb-1">Versements</p>
              <p className="text-lg font-semibold">
                {filteredTransactions.filter(t => t.status === 'success').length} / {filteredTransactions.length}
              </p>
            </div>
          </div>
        </Card>

        {/* Filters */}
        <div className="flex gap-3 animate-slide-up" style={{ animationDelay: '0.1s' }}>
          <Select value={yearFilter} onValueChange={setYearFilter}>
            <SelectTrigger className="w-[140px]">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Année" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Toutes</SelectItem>
              {years.map(year => (
                <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Statut" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous</SelectItem>
              <SelectItem value="success">Reçus</SelectItem>
              <SelectItem value="pending">En attente</SelectItem>
              <SelectItem value="failed">Échecs</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Transactions List */}
        <div className="space-y-3">
          {filteredTransactions.map((txn, i) => (
            <Card 
              key={txn.id}
              className="p-4 hover:shadow-card-hover transition-all animate-slide-up cursor-pointer"
              style={{ animationDelay: `${0.05 * i}s` }}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-full ${
                    txn.status === 'success' ? 'bg-success/10' :
                    txn.status === 'pending' ? 'bg-warning/10' : 'bg-error/10'
                  }`}>
                    {getStatusIcon(txn.status)}
                  </div>
                  <div>
                    <p className="font-semibold mb-1">
                      {new Date(txn.date).toLocaleDateString('fr-FR', { 
                        month: 'long', 
                        year: 'numeric' 
                      })}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {formatDate(txn.date)}
                    </p>
                    <Badge 
                      variant="outline" 
                      className={`mt-2 ${
                        txn.status === 'success' ? 'status-success' :
                        txn.status === 'pending' ? 'status-warning' : 'status-error'
                      }`}
                    >
                      {getStatusText(txn.status)}
                    </Badge>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`text-lg font-bold ${
                    txn.status === 'success' ? 'text-success' :
                    txn.status === 'failed' ? 'text-error' : 'text-warning'
                  }`}>
                    {txn.status === 'success' ? '+' : ''}{txn.amount.toLocaleString()} F
                  </p>
                  {txn.fees > 0 && (
                    <p className="text-xs text-muted-foreground">
                      Frais: {txn.fees} F
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground mt-1">
                    {txn.paymentChannel}
                  </p>
                </div>
              </div>

              {/* Error Message */}
              {txn.status === 'failed' && txn.errorMessage && (
                <div className="mt-3 p-2 bg-error/10 rounded-lg">
                  <p className="text-sm text-error">
                    ⚠️ {txn.errorMessage}
                  </p>
                </div>
              )}

              {/* Reference */}
              <div className="mt-3 pt-3 border-t border-border flex items-center justify-between">
                <span className="text-xs text-muted-foreground font-mono">
                  Réf: {txn.reference.slice(0, 15)}...
                </span>
                {txn.status === 'success' && (
                  <Button variant="ghost" size="sm" className="h-7 text-xs">
                    <FileText className="h-3 w-3 mr-1" />
                    Reçu
                  </Button>
                )}
              </div>
            </Card>
          ))}

          {filteredTransactions.length === 0 && (
            <Card className="p-8 text-center">
              <Calendar className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground">Aucun versement trouvé</p>
            </Card>
          )}
        </div>

        {/* Export Button */}
        {filteredTransactions.length > 0 && (
          <Button variant="outline" className="w-full gap-2 animate-slide-up">
            <Download className="h-4 w-4" />
            Télécharger l'historique (PDF)
          </Button>
        )}
      </div>
    </div>
  );
}
