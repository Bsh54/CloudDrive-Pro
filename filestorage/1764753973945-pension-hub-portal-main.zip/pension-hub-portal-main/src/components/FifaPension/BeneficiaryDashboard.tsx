import { useState, useEffect } from 'react';
import { 
  Calendar, CreditCard, CheckCircle2, AlertTriangle, Clock, 
  ChevronRight, History, User, HelpCircle, Phone, FileText,
  Bell, Shield, TrendingUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { type Beneficiary, type Transaction, transactions } from '@/data/mockData';

interface BeneficiaryDashboardProps {
  beneficiary: Beneficiary;
  onNavigate: (view: string) => void;
}

export function BeneficiaryDashboard({ beneficiary, onNavigate }: BeneficiaryDashboardProps) {
  const [nextPayment, setNextPayment] = useState({
    amount: beneficiary.monthlyAmount,
    date: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 15),
    status: 'scheduled' as 'scheduled' | 'processing' | 'failed',
  });
  
  const benTransactions = transactions
    .filter(t => t.beneficiaryId === beneficiary.id)
    .slice(0, 5);
  
  const lastTransaction = benTransactions[0];
  const hasError = lastTransaction?.status === 'failed';

  // Simulate payment status changes
  useEffect(() => {
    const interval = setInterval(() => {
      const rand = Math.random();
      if (rand > 0.95) {
        setNextPayment(prev => ({
          ...prev,
          status: 'processing',
        }));
      }
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'scheduled':
        return <Badge className="bg-primary/10 text-primary border-primary/20">🟢 Prévu</Badge>;
      case 'processing':
        return <Badge className="bg-warning/10 text-warning border-warning/20">🟡 En cours</Badge>;
      case 'failed':
        return <Badge className="bg-error/10 text-error border-error/20">🔴 Échec</Badge>;
      default:
        return null;
    }
  };

  const formatDate = (date: Date | string) => {
    const d = new Date(date);
    return d.toLocaleDateString('fr-FR', { 
      day: 'numeric', 
      month: 'long', 
      year: 'numeric' 
    });
  };

  const daysUntilPayment = Math.ceil(
    (nextPayment.date.getTime() - Date.now()) / (1000 * 60 * 60 * 24)
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Welcome Header */}
      <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground p-6 pb-24">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <img 
                src={beneficiary.photo} 
                alt="" 
                className="w-12 h-12 rounded-full border-2 border-primary-foreground/30"
              />
              <div>
                <p className="text-primary-foreground/80 text-sm">Bonjour,</p>
                <h1 className="text-xl font-semibold">{beneficiary.firstName} {beneficiary.lastName}</h1>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="icon"
              className="text-primary-foreground hover:bg-primary-foreground/10"
            >
              <Bell className="h-5 w-5" />
            </Button>
          </div>
          <p className="text-primary-foreground/70 text-sm">
            ID: {beneficiary.id} • {beneficiary.region}
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 -mt-20 pb-24 space-y-4">
        {/* Error Alert Banner */}
        {hasError && (
          <Card className="bg-error text-error-foreground p-4 animate-slide-up border-none">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-6 w-6 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <h3 className="font-semibold mb-1">Paiement échoué</h3>
                <p className="text-sm opacity-90 mb-3">
                  Votre dernier versement n'a pas abouti. {lastTransaction?.errorMessage}
                </p>
                <Button 
                  size="sm" 
                  className="bg-primary-foreground text-error hover:bg-primary-foreground/90"
                >
                  <Phone className="h-4 w-4 mr-2" />
                  Composez *123# pour corriger
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Next Payment Card */}
        <Card className="p-6 animate-slide-up shadow-card" style={{ animationDelay: '0.1s' }}>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-primary" />
              Prochain versement
            </h2>
            {getStatusBadge(nextPayment.status)}
          </div>
          
          <div className="text-center py-6">
            <p className="text-muted-foreground text-sm mb-2">Montant</p>
            <p className="payment-amount mb-2">
              {nextPayment.amount.toLocaleString()} <span className="text-2xl">FCFA</span>
            </p>
            <div className="flex items-center justify-center gap-2 text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <span>{formatDate(nextPayment.date)}</span>
            </div>
          </div>

          <div className="bg-secondary/50 rounded-lg p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Dans</span>
            </div>
            <span className="text-lg font-semibold text-primary">
              {daysUntilPayment} jours
            </span>
          </div>
        </Card>

        {/* Proof of Life Widget */}
        {beneficiary.proofOfLifeStatus !== 'valid' && (
          <Card className="p-4 border-warning/50 bg-warning/5 animate-slide-up" style={{ animationDelay: '0.15s' }}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-full bg-warning/10">
                  <Shield className="h-5 w-5 text-warning" />
                </div>
                <div>
                  <h3 className="font-medium">Preuve de vie</h3>
                  <p className="text-sm text-muted-foreground">
                    {beneficiary.proofOfLifeStatus === 'pending' 
                      ? 'En attente de validation'
                      : 'Expirée - Action requise'}
                  </p>
                </div>
              </div>
              <Button variant="outline" size="sm" className="border-warning text-warning hover:bg-warning/10">
                Mettre à jour
              </Button>
            </div>
          </Card>
        )}

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4 animate-slide-up" style={{ animationDelay: '0.2s' }}>
          <Card 
            className="p-4 cursor-pointer hover:shadow-card-hover transition-all hover:-translate-y-0.5"
            onClick={() => onNavigate('history')}
          >
            <div className="flex flex-col items-center text-center gap-3">
              <div className="p-3 rounded-full bg-primary/10">
                <History className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Historique</h3>
                <p className="text-xs text-muted-foreground">Voir mes versements</p>
              </div>
            </div>
          </Card>

          <Card 
            className="p-4 cursor-pointer hover:shadow-card-hover transition-all hover:-translate-y-0.5"
            onClick={() => onNavigate('profile')}
          >
            <div className="flex flex-col items-center text-center gap-3">
              <div className="p-3 rounded-full bg-accent/20">
                <User className="h-6 w-6 text-accent-foreground" />
              </div>
              <div>
                <h3 className="font-medium">Mon profil</h3>
                <p className="text-xs text-muted-foreground">Infos & canal</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Recent Transactions */}
        <Card className="p-6 animate-slide-up" style={{ animationDelay: '0.25s' }}>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Derniers versements</h3>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-primary"
              onClick={() => onNavigate('history')}
            >
              Tout voir <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="space-y-3">
            {benTransactions.slice(0, 3).map((txn, i) => (
              <div 
                key={txn.id}
                className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg"
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${
                    txn.status === 'success' ? 'bg-success/10' :
                    txn.status === 'pending' ? 'bg-warning/10' : 'bg-error/10'
                  }`}>
                    {txn.status === 'success' ? (
                      <CheckCircle2 className="h-4 w-4 text-success" />
                    ) : txn.status === 'pending' ? (
                      <Clock className="h-4 w-4 text-warning" />
                    ) : (
                      <AlertTriangle className="h-4 w-4 text-error" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-sm">
                      {new Date(txn.date).toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {txn.status === 'success' ? 'Reçu' : 
                       txn.status === 'pending' ? 'En attente' : 'Échec'}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`font-semibold ${
                    txn.status === 'success' ? 'text-success' :
                    txn.status === 'failed' ? 'text-error' : 'text-warning'
                  }`}>
                    {txn.status === 'success' ? '+' : ''}{txn.amount.toLocaleString()} F
                  </p>
                  {txn.fees > 0 && (
                    <p className="text-xs text-muted-foreground">Frais: {txn.fees} F</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Help Section */}
        <Card 
          className="p-4 cursor-pointer hover:shadow-card-hover transition-all animate-slide-up"
          style={{ animationDelay: '0.3s' }}
          onClick={() => onNavigate('help')}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-full bg-muted">
                <HelpCircle className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <h3 className="font-medium">Besoin d'aide ?</h3>
                <p className="text-xs text-muted-foreground">FAQ, contact, chatbot Nanon</p>
              </div>
            </div>
            <ChevronRight className="h-5 w-5 text-muted-foreground" />
          </div>
        </Card>

        {/* USSD Reminder */}
        <div className="text-center py-4 animate-slide-up" style={{ animationDelay: '0.35s' }}>
          <p className="text-sm text-muted-foreground mb-2">Accès rapide par téléphone</p>
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full font-mono text-lg font-bold">
            <Phone className="h-4 w-4" />
            *123#
          </div>
        </div>
      </div>
    </div>
  );
}
