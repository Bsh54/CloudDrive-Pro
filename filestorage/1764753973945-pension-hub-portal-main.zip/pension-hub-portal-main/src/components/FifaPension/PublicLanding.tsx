import { 
  Shield, Phone, Users, CheckCircle2, ArrowRight, 
  Star, ChevronRight, MessageCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface PublicLandingProps {
  onLogin: () => void;
  onAdminLogin: () => void;
}

export function PublicLanding({ onLogin, onAdminLogin }: PublicLandingProps) {
  const testimonials = [
    {
      name: "Koffi Mensah",
      region: "Cotonou",
      quote: "Grâce à FIFA Pension, je reçois ma pension sans me déplacer. C'est simple et fiable !",
      avatar: "https://api.dicebear.com/7.x/personas/svg?seed=Koffi"
    },
    {
      name: "Adjovi Dossou",
      region: "Porto-Novo",
      quote: "Le service *123# est vraiment pratique pour consulter mon solde.",
      avatar: "https://api.dicebear.com/7.x/personas/svg?seed=Adjovi"
    },
    {
      name: "Hounkpatin Gandonou",
      region: "Parakou",
      quote: "L'équipe est toujours disponible pour m'aider. Merci FIFA Pension !",
      avatar: "https://api.dicebear.com/7.x/personas/svg?seed=Hounkpatin"
    },
  ];

  const features = [
    {
      icon: Shield,
      title: "Sécurisé",
      description: "Vos informations sont protégées avec les plus hauts standards de sécurité."
    },
    {
      icon: Phone,
      title: "Accessible",
      description: "Consultez votre pension par téléphone, USSD (*123#) ou en ligne."
    },
    {
      icon: Users,
      title: "Support 24/7",
      description: "Notre équipe et Nanon, votre assistante virtuelle, sont toujours là pour vous."
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <header className="relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/5" />
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
        </div>

        {/* Navigation */}
        <nav className="relative z-10 container mx-auto px-4 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-primary text-primary-foreground flex items-center justify-center">
              <Shield className="h-7 w-7" />
            </div>
            <div>
              <h1 className="font-bold text-xl text-foreground">FIFA Pension</h1>
              <p className="text-xs text-muted-foreground">Bénin</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" onClick={onAdminLogin} className="hidden sm:flex">
              Admin
            </Button>
            <Button onClick={onLogin}>
              Connexion
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </nav>

        {/* Hero Content */}
        <div className="relative z-10 container mx-auto px-4 py-16 md:py-24">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-accent/10 text-accent-foreground px-4 py-2 rounded-full text-sm font-medium mb-6 animate-slide-up">
              <CheckCircle2 className="h-4 w-4" />
              Plus de 50 000 bénéficiaires au Bénin
            </div>
            
            <h2 className="text-display text-foreground mb-6 animate-slide-up" style={{ animationDelay: '0.1s' }}>
              La pension, l'esprit{' '}
              <span className="text-gradient">tranquille</span>
            </h2>
            
            <p className="text-body-lg text-muted-foreground mb-8 animate-slide-up" style={{ animationDelay: '0.2s' }}>
              FIFA Pension simplifie l'accès à votre pension retraite. 
              Recevez vos versements en toute sécurité, directement sur votre téléphone ou compte bancaire.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-slide-up" style={{ animationDelay: '0.3s' }}>
              <Button size="lg" onClick={onLogin} className="gap-2 px-8">
                Accéder à mon espace
                <ArrowRight className="h-5 w-5" />
              </Button>
              <div className="flex items-center gap-2 text-muted-foreground">
                <span>ou composez</span>
                <span className="font-mono font-bold text-primary text-lg bg-primary/10 px-3 py-1 rounded-lg">
                  *123#
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* USSD Banner */}
        <div className="relative z-10 container mx-auto px-4 pb-16">
          <Card className="max-w-2xl mx-auto p-6 bg-gradient-to-r from-primary to-primary/90 text-primary-foreground border-none animate-slide-up" style={{ animationDelay: '0.4s' }}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-primary-foreground/20 flex items-center justify-center">
                  <Phone className="h-7 w-7" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Accès USSD rapide</h3>
                  <p className="text-primary-foreground/80">Sans internet, depuis n'importe quel téléphone</p>
                </div>
              </div>
              <div className="text-3xl font-mono font-bold">*123#</div>
            </div>
          </Card>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-16 bg-secondary/30">
        <div className="container mx-auto px-4">
          <h3 className="text-headline text-center mb-12">Pourquoi FIFA Pension ?</h3>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {features.map((feature, i) => (
              <Card 
                key={feature.title}
                className="p-6 text-center hover:shadow-card-hover transition-all hover:-translate-y-1 animate-slide-up"
                style={{ animationDelay: `${0.1 * i}s` }}
              >
                <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="h-7 w-7 text-primary" />
                </div>
                <h4 className="text-title mb-2">{feature.title}</h4>
                <p className="text-muted-foreground">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h3 className="text-headline text-center mb-4">Ils nous font confiance</h3>
          <p className="text-muted-foreground text-center mb-12 max-w-2xl mx-auto">
            Découvrez les témoignages de nos bénéficiaires à travers tout le Bénin.
          </p>
          
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {testimonials.map((testimonial, i) => (
              <Card 
                key={testimonial.name}
                className="p-6 animate-slide-up"
                style={{ animationDelay: `${0.1 * i}s` }}
              >
                <div className="flex items-center gap-1 text-accent mb-4">
                  {[...Array(5)].map((_, j) => (
                    <Star key={j} className="h-4 w-4 fill-current" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-4 italic">"{testimonial.quote}"</p>
                <div className="flex items-center gap-3">
                  <img 
                    src={testimonial.avatar} 
                    alt="" 
                    className="w-10 h-10 rounded-full bg-muted"
                  />
                  <div>
                    <p className="font-medium">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.region}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-headline mb-4">Prêt à commencer ?</h3>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Connectez-vous à votre espace personnel ou contactez notre support pour toute assistance.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button size="lg" onClick={onLogin}>
              Se connecter
              <ArrowRight className="h-5 w-5 ml-2" />
            </Button>
            <Button size="lg" variant="outline">
              <MessageCircle className="h-5 w-5 mr-2" />
              Contacter le support
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-border">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Shield className="h-6 w-6 text-primary" />
              <span className="font-semibold">FIFA Pension Bénin</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 FIFA Pension. Tous droits réservés.
            </p>
            <div className="flex items-center gap-4">
              <button className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Confidentialité
              </button>
              <button className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Conditions
              </button>
              <button className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Contact
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
