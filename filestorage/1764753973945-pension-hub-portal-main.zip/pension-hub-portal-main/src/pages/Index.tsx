import { useState, useEffect } from 'react';
import { PublicLanding } from '@/components/FifaPension/PublicLanding';
import { LoginPage } from '@/components/FifaPension/LoginPage';
import { AdminSidebar } from '@/components/FifaPension/AdminSidebar';
import { AdminDashboard } from '@/components/FifaPension/AdminDashboard';
import { AdminBeneficiaries } from '@/components/FifaPension/AdminBeneficiaries';
import { BeneficiaryNavbar } from '@/components/FifaPension/BeneficiaryNavbar';
import { BeneficiaryDashboard } from '@/components/FifaPension/BeneficiaryDashboard';
import { BeneficiaryHistory } from '@/components/FifaPension/BeneficiaryHistory';
import { BeneficiaryProfile } from '@/components/FifaPension/BeneficiaryProfile';
import { BeneficiaryHelp } from '@/components/FifaPension/BeneficiaryHelp';
import { ChatbotNanon } from '@/components/FifaPension/ChatbotNanon';
import { beneficiaries, type Beneficiary } from '@/data/mockData';
import { Toaster } from '@/components/ui/toaster';

type AppView = 
  | 'landing' 
  | 'login-admin' 
  | 'login-beneficiary'
  | 'admin-dashboard'
  | 'admin-beneficiaries'
  | 'admin-errors'
  | 'admin-audit'
  | 'admin-settings'
  | 'ben-dashboard'
  | 'ben-history'
  | 'ben-profile'
  | 'ben-help';

export default function Index() {
  const [currentView, setCurrentView] = useState<AppView>('landing');
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [isBeneficiaryLoggedIn, setIsBeneficiaryLoggedIn] = useState(false);
  const [currentBeneficiary, setCurrentBeneficiary] = useState<Beneficiary | null>(null);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // Check for saved session
  useEffect(() => {
    const savedSession = localStorage.getItem('fifapension_session');
    if (savedSession) {
      const session = JSON.parse(savedSession);
      if (session.type === 'admin') {
        setIsAdminLoggedIn(true);
        setCurrentView('admin-dashboard');
      } else if (session.type === 'beneficiary') {
        const ben = beneficiaries.find(b => b.phone.includes(session.phone));
        if (ben) {
          setCurrentBeneficiary(ben);
          setIsBeneficiaryLoggedIn(true);
          setCurrentView('ben-dashboard');
        }
      }
    }
  }, []);

  const handleAdminLogin = (credentials: { username: string; password: string }) => {
    localStorage.setItem('fifapension_session', JSON.stringify({ type: 'admin' }));
    setIsAdminLoggedIn(true);
    setCurrentView('admin-dashboard');
  };

  const handleBeneficiaryLogin = (credentials: { username: string; password: string }) => {
    // Find a matching beneficiary or use the first one for demo
    const ben = beneficiaries.find(b => b.phone.includes(credentials.username.slice(-8))) || beneficiaries[0];
    localStorage.setItem('fifapension_session', JSON.stringify({ 
      type: 'beneficiary', 
      phone: ben.phone 
    }));
    setCurrentBeneficiary(ben);
    setIsBeneficiaryLoggedIn(true);
    setCurrentView('ben-dashboard');
  };

  const handleLogout = () => {
    localStorage.removeItem('fifapension_session');
    setIsAdminLoggedIn(false);
    setIsBeneficiaryLoggedIn(false);
    setCurrentBeneficiary(null);
    setCurrentView('landing');
  };

  const handleAdminNavigate = (view: string) => {
    setCurrentView(`admin-${view}` as AppView);
  };

  const handleBeneficiaryNavigate = (view: string) => {
    setCurrentView(`ben-${view}` as AppView);
  };

  const handleUpdateBeneficiary = (updated: Beneficiary) => {
    setCurrentBeneficiary(updated);
  };

  // Landing Page
  if (currentView === 'landing') {
    return (
      <>
        <PublicLanding 
          onLogin={() => setCurrentView('login-beneficiary')}
          onAdminLogin={() => setCurrentView('login-admin')}
        />
        <ChatbotNanon beneficiary={null} />
      </>
    );
  }

  // Login Pages
  if (currentView === 'login-admin') {
    return (
      <LoginPage 
        type="admin"
        onLogin={handleAdminLogin}
        onSwitchType={() => setCurrentView('login-beneficiary')}
      />
    );
  }

  if (currentView === 'login-beneficiary') {
    return (
      <LoginPage 
        type="beneficiary"
        onLogin={handleBeneficiaryLogin}
        onSwitchType={() => setCurrentView('login-admin')}
      />
    );
  }

  // Admin Interface
  if (isAdminLoggedIn && currentView.startsWith('admin-')) {
    return (
      <div className="admin-theme min-h-screen bg-background flex">
        <AdminSidebar
          currentView={currentView.replace('admin-', '')}
          onNavigate={handleAdminNavigate}
          onLogout={handleLogout}
          isCollapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        />
        <main className="flex-1 overflow-y-auto">
          {currentView === 'admin-dashboard' && (
            <AdminDashboard 
              onNavigate={handleAdminNavigate}
              onSelectBeneficiary={(ben) => {
                setCurrentBeneficiary(ben);
              }}
            />
          )}
          {currentView === 'admin-beneficiaries' && (
            <AdminBeneficiaries 
              onSelectBeneficiary={(ben) => {
                setCurrentBeneficiary(ben);
              }}
            />
          )}
          {currentView === 'admin-errors' && (
            <AdminDashboard 
              onNavigate={handleAdminNavigate}
              onSelectBeneficiary={(ben) => {
                setCurrentBeneficiary(ben);
              }}
            />
          )}
          {currentView === 'admin-audit' && (
            <div className="p-6">
              <h1 className="text-2xl font-bold mb-4">Journal d'audit</h1>
              <p className="text-muted-foreground">Historique des actions administratives...</p>
            </div>
          )}
          {currentView === 'admin-settings' && (
            <div className="p-6">
              <h1 className="text-2xl font-bold mb-4">Paramètres</h1>
              <p className="text-muted-foreground">Configuration du système...</p>
            </div>
          )}
        </main>
        <Toaster />
      </div>
    );
  }

  // Beneficiary Interface
  if (isBeneficiaryLoggedIn && currentBeneficiary && currentView.startsWith('ben-')) {
    return (
      <div className="min-h-screen bg-background">
        {currentView === 'ben-dashboard' && (
          <BeneficiaryDashboard 
            beneficiary={currentBeneficiary}
            onNavigate={handleBeneficiaryNavigate}
          />
        )}
        {currentView === 'ben-history' && (
          <BeneficiaryHistory 
            beneficiary={currentBeneficiary}
            onBack={() => setCurrentView('ben-dashboard')}
          />
        )}
        {currentView === 'ben-profile' && (
          <BeneficiaryProfile 
            beneficiary={currentBeneficiary}
            onBack={() => setCurrentView('ben-dashboard')}
            onUpdate={handleUpdateBeneficiary}
          />
        )}
        {currentView === 'ben-help' && (
          <BeneficiaryHelp 
            onBack={() => setCurrentView('ben-dashboard')}
          />
        )}
        
        <BeneficiaryNavbar
          currentView={currentView.replace('ben-', '')}
          onNavigate={handleBeneficiaryNavigate}
          onLogout={handleLogout}
        />
        <ChatbotNanon beneficiary={currentBeneficiary} />
        <Toaster />
      </div>
    );
  }

  // Fallback to landing
  return (
    <>
      <PublicLanding 
        onLogin={() => setCurrentView('login-beneficiary')}
        onAdminLogin={() => setCurrentView('login-admin')}
      />
      <ChatbotNanon beneficiary={null} />
    </>
  );
}
