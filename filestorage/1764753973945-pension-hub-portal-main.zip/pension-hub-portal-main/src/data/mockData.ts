// Mock Data for FIFA Pension Platform

export interface Beneficiary {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  pin: string;
  photo: string;
  dateOfBirth: string;
  registrationDate: string;
  paymentChannel: 'mtn' | 'moov' | 'bank';
  channelNumber: string;
  proofOfLifeStatus: 'valid' | 'pending' | 'expired';
  proofOfLifeDate: string;
  monthlyAmount: number;
  status: 'active' | 'suspended' | 'deceased';
  address: string;
  region: string;
}

export interface Transaction {
  id: string;
  beneficiaryId: string;
  amount: number;
  fees: number;
  date: string;
  status: 'success' | 'pending' | 'failed';
  paymentChannel: string;
  reference: string;
  errorCode?: string;
  errorMessage?: string;
}

export interface PaymentError {
  id: string;
  beneficiaryId: string;
  transactionId: string;
  timestamp: string;
  mojaCode: string;
  mojaMessage: string;
  humanMessage: string;
  fsp: string;
  amount: number;
  attempts: number;
  status: 'pending' | 'resolved' | 'escalated';
}

export interface FSPStatus {
  name: string;
  code: string;
  status: 'healthy' | 'warning' | 'critical';
  latency: number;
  successRate: number;
  lastCheck: string;
}

// Mojaloop Error Codes
export const mojaErrorCodes: Record<string, { code: string; human: string }> = {
  '3201': { code: 'ACCOUNT_INVALID', human: 'Numéro de compte invalide' },
  '3202': { code: 'PAYEE_NOT_FOUND', human: 'Bénéficiaire introuvable' },
  '3203': { code: 'ACCOUNT_BLOCKED', human: 'Compte bloqué' },
  '3204': { code: 'INSUFFICIENT_FUNDS', human: 'Fonds insuffisants (FSP)' },
  '3205': { code: 'TIMEOUT', human: 'Délai de réponse dépassé' },
  '3206': { code: 'LIMIT_EXCEEDED', human: 'Limite de transaction dépassée' },
  '3207': { code: 'INVALID_PHONE', human: 'Numéro de téléphone invalide' },
  '5100': { code: 'FSP_UNAVAILABLE', human: 'Service FSP indisponible' },
};

// Generate realistic beneficiaries
const firstNames = ['Koffi', 'Adjovi', 'Kossi', 'Akouavi', 'Codjo', 'Ablawa', 'Hounkpatin', 'Houéfa', 'Sèna', 'Afiavi', 'Gbaguidi', 'Toussaint', 'Félicien', 'Marcelline', 'Théophile', 'Pélagie', 'Médard', 'Clémentine', 'Augustin', 'Victorine'];
const lastNames = ['Ahouandjinou', 'Dossou', 'Gandonou', 'Hounkonnou', 'Kpadonou', 'Loko', 'Mensah', 'Nouatin', 'Oké', 'Padonou', 'Quenum', 'Sèmassou', 'Tossou', 'Vodounou', 'Zinsou', 'Agboton', 'Boco', 'Capo-Chichi', 'Djènontin', 'Fassinou'];
const regions = ['Littoral', 'Atlantique', 'Ouémé', 'Plateau', 'Zou', 'Collines', 'Borgou', 'Alibori', 'Atacora', 'Donga', 'Mono', 'Couffo'];

export const generateBeneficiaries = (count: number): Beneficiary[] => {
  return Array.from({ length: count }, (_, i) => {
    const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
    const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
    const channel = ['mtn', 'moov', 'bank'][Math.floor(Math.random() * 3)] as 'mtn' | 'moov' | 'bank';
    const phonePrefix = channel === 'mtn' ? '96' : channel === 'moov' ? '97' : '95';
    
    return {
      id: `BEN-${String(i + 1).padStart(5, '0')}`,
      firstName,
      lastName,
      phone: `+229 ${phonePrefix}${String(Math.floor(Math.random() * 90000000) + 10000000)}`,
      pin: String(Math.floor(Math.random() * 9000) + 1000),
      photo: `https://api.dicebear.com/7.x/personas/svg?seed=${firstName}${lastName}`,
      dateOfBirth: `${1945 + Math.floor(Math.random() * 20)}-${String(Math.floor(Math.random() * 12) + 1).padStart(2, '0')}-${String(Math.floor(Math.random() * 28) + 1).padStart(2, '0')}`,
      registrationDate: `202${Math.floor(Math.random() * 4)}-${String(Math.floor(Math.random() * 12) + 1).padStart(2, '0')}-${String(Math.floor(Math.random() * 28) + 1).padStart(2, '0')}`,
      paymentChannel: channel,
      channelNumber: channel === 'bank' ? `BJ${String(Math.floor(Math.random() * 900000000) + 100000000)}` : `+229 ${phonePrefix}${String(Math.floor(Math.random() * 90000000) + 10000000)}`,
      proofOfLifeStatus: ['valid', 'pending', 'expired'][Math.floor(Math.random() * 3)] as 'valid' | 'pending' | 'expired',
      proofOfLifeDate: `2024-${String(Math.floor(Math.random() * 12) + 1).padStart(2, '0')}-${String(Math.floor(Math.random() * 28) + 1).padStart(2, '0')}`,
      monthlyAmount: 35000 + Math.floor(Math.random() * 15000),
      status: Math.random() > 0.1 ? 'active' : (Math.random() > 0.5 ? 'suspended' : 'deceased'),
      address: `Quartier ${['Akpakpa', 'Cadjèhoun', 'Houéyiho', 'Fidjrossè', 'Agla', 'Gbégamey'][Math.floor(Math.random() * 6)]}`,
      region: regions[Math.floor(Math.random() * regions.length)],
    };
  });
};

export const generateTransactions = (beneficiaries: Beneficiary[], monthsBack: number = 12): Transaction[] => {
  const transactions: Transaction[] = [];
  const now = new Date();
  
  beneficiaries.forEach(ben => {
    for (let m = 0; m < monthsBack; m++) {
      const date = new Date(now.getFullYear(), now.getMonth() - m, 15);
      const status = Math.random() > 0.15 ? 'success' : (Math.random() > 0.5 ? 'failed' : 'pending');
      const errorCodes = Object.keys(mojaErrorCodes);
      const randomError = errorCodes[Math.floor(Math.random() * errorCodes.length)];
      
      transactions.push({
        id: `TXN-${ben.id}-${date.toISOString().slice(0, 7).replace('-', '')}`,
        beneficiaryId: ben.id,
        amount: ben.monthlyAmount,
        fees: Math.random() > 0.7 ? 150 : 0,
        date: date.toISOString(),
        status,
        paymentChannel: ben.paymentChannel.toUpperCase(),
        reference: `REF${Date.now()}${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
        ...(status === 'failed' && {
          errorCode: randomError,
          errorMessage: mojaErrorCodes[randomError].human,
        }),
      });
    }
  });
  
  return transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const generatePaymentErrors = (transactions: Transaction[], beneficiaries: Beneficiary[]): PaymentError[] => {
  const failedTxns = transactions.filter(t => t.status === 'failed');
  
  return failedTxns.slice(0, 15).map((txn, i) => {
    const ben = beneficiaries.find(b => b.id === txn.beneficiaryId)!;
    const errorCode = txn.errorCode || '3201';
    const errorInfo = mojaErrorCodes[errorCode];
    
    return {
      id: `ERR-${String(i + 1).padStart(4, '0')}`,
      beneficiaryId: txn.beneficiaryId,
      transactionId: txn.id,
      timestamp: txn.date,
      mojaCode: errorCode,
      mojaMessage: errorInfo.code,
      humanMessage: errorInfo.human,
      fsp: ben.paymentChannel.toUpperCase(),
      amount: txn.amount,
      attempts: Math.floor(Math.random() * 3) + 1,
      status: ['pending', 'resolved', 'escalated'][Math.floor(Math.random() * 3)] as 'pending' | 'resolved' | 'escalated',
    };
  });
};

export const fspStatuses: FSPStatus[] = [
  { name: 'MTN MoMo', code: 'MTN', status: 'healthy', latency: 245, successRate: 98.5, lastCheck: new Date().toISOString() },
  { name: 'Moov Money', code: 'MOOV', status: 'warning', latency: 890, successRate: 94.2, lastCheck: new Date().toISOString() },
  { name: 'BCEAO', code: 'BANK', status: 'healthy', latency: 180, successRate: 99.1, lastCheck: new Date().toISOString() },
  { name: 'UBA Bénin', code: 'UBA', status: 'critical', latency: 2100, successRate: 78.3, lastCheck: new Date().toISOString() },
];

// Initialize mock data
export const beneficiaries = generateBeneficiaries(50);
export const transactions = generateTransactions(beneficiaries);
export const paymentErrors = generatePaymentErrors(transactions, beneficiaries);

// KPI calculations
export const calculateKPIs = () => {
  const thisMonth = transactions.filter(t => {
    const txnDate = new Date(t.date);
    const now = new Date();
    return txnDate.getMonth() === now.getMonth() && txnDate.getFullYear() === now.getFullYear();
  });
  
  const successCount = thisMonth.filter(t => t.status === 'success').length;
  const totalCount = thisMonth.length;
  const successRate = totalCount > 0 ? (successCount / totalCount) * 100 : 0;
  const totalAmount = thisMonth.filter(t => t.status === 'success').reduce((sum, t) => sum + t.amount, 0);
  const pendingErrors = paymentErrors.filter(e => e.status === 'pending').length;
  
  return {
    successRate: Math.round(successRate * 10) / 10,
    totalAmount,
    pendingErrors,
    totalBeneficiaries: beneficiaries.filter(b => b.status === 'active').length,
    liquidityAvailable: 125000000, // 125M FCFA
    monthlyBudget: 150000000, // 150M FCFA
  };
};
